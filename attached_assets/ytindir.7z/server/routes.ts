import type { Express } from "express";
import { createServer, type Server } from "http";
import { z } from "zod";
import { validateYouTubeURL, extractVideoId } from "../client/src/lib/youtube-utils";

const videoInfoSchema = z.object({
  url: z.string().url()
});

const downloadRequestSchema = z.object({
  url: z.string().url(),
  quality: z.string()
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Video information endpoint
  app.post("/api/video-info", async (req, res) => {
    try {
      const { url } = videoInfoSchema.parse(req.body);
      
      if (!validateYouTubeURL(url)) {
        return res.status(400).json({ 
          error: "Invalid YouTube URL format. Please check the URL and try again." 
        });
      }

      const videoId = extractVideoId(url);
      if (!videoId) {
        return res.status(400).json({ 
          error: "Could not extract video ID from URL" 
        });
      }

      // Simulate video info (in production, this would call yt-dlp or YouTube API)
      const mockVideoInfo = {
        title: "Sample Video Title",
        duration: "10:30",
        channel: "Sample Channel",
        thumbnail: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?ixlib=rb-4.0.3&w=320&h=240",
        formats: ["360p", "720p", "1080p"],
        videoId
      };

      // Simulate age restriction check (5% chance for demo)
      if (Math.random() < 0.05) {
        return res.status(403).json({ 
          error: "This video is age-restricted and cannot be processed" 
        });
      }

      res.json(mockVideoInfo);
    } catch (error) {
      console.error("Video info error:", error);
      res.status(500).json({ 
        error: "Failed to fetch video information" 
      });
    }
  });

  // Download preparation endpoint
  app.post("/api/prepare-download", async (req, res) => {
    try {
      const { url, quality } = downloadRequestSchema.parse(req.body);
      
      if (!validateYouTubeURL(url)) {
        return res.status(400).json({ 
          error: "Invalid YouTube URL" 
        });
      }

      // Simulate processing delay
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Simulate random failures (5% chance)
      if (Math.random() < 0.05) {
        return res.status(500).json({ 
          error: "Video processing failed. Please try again." 
        });
      }

      res.json({ 
        success: true, 
        downloadReady: true,
        quality,
        message: "Download prepared successfully" 
      });
    } catch (error) {
      console.error("Download preparation error:", error);
      res.status(500).json({ 
        error: "Failed to prepare download" 
      });
    }
  });

  // Download endpoint
  app.post("/api/download", async (req, res) => {
    try {
      const { url, quality } = downloadRequestSchema.parse(req.body);
      
      if (!validateYouTubeURL(url)) {
        return res.status(400).json({ 
          error: "Invalid YouTube URL" 
        });
      }

      // In production, this would stream the actual video file
      // For now, we'll create a small dummy file to demonstrate
      const dummyContent = `Mock video file for ${url} at ${quality} quality`;
      const buffer = Buffer.from(dummyContent);

      res.setHeader('Content-Type', 'video/mp4');
      res.setHeader('Content-Disposition', 'attachment; filename="video.mp4"');
      res.setHeader('Content-Length', buffer.length);
      
      res.send(buffer);
    } catch (error) {
      console.error("Download error:", error);
      res.status(500).json({ 
        error: "Download failed" 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
