import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table (keeping existing structure)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

// Download requests table for analytics (transient data)
export const downloadRequests = pgTable("download_requests", {
  id: serial("id").primaryKey(),
  videoId: text("video_id").notNull(),
  quality: text("quality").notNull(),
  status: text("status").notNull(), // 'processing', 'completed', 'failed'
  createdAt: timestamp("created_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
  errorMessage: text("error_message"),
  ipAddress: text("ip_address"), // For rate limiting
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertDownloadRequestSchema = createInsertSchema(downloadRequests).pick({
  videoId: true,
  quality: true,
  status: true,
  errorMessage: true,
  ipAddress: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertDownloadRequest = z.infer<typeof insertDownloadRequestSchema>;
export type DownloadRequest = typeof downloadRequests.$inferSelect;

// YouTube URL validation schema
export const youtubeUrlSchema = z.object({
  url: z.string().url().refine(
    (url) => /(youtu\.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/.test(url),
    { message: "Must be a valid YouTube URL" }
  ),
});

// Quality selection schema
export const qualitySchema = z.enum(["360p", "480p", "720p", "1080p", "1440p", "2160p"]);

// Download request schema
export const downloadRequestSchema = z.object({
  url: youtubeUrlSchema.shape.url,
  quality: qualitySchema,
});

export type YoutubeUrl = z.infer<typeof youtubeUrlSchema>;
export type Quality = z.infer<typeof qualitySchema>;
export type DownloadRequestInput = z.infer<typeof downloadRequestSchema>;
