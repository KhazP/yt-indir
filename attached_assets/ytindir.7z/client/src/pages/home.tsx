import { useState } from "react";
import DownloadCard from "@/components/download-card";
import LegalCompliance from "@/components/legal-compliance";
import FeaturesGrid from "@/components/features-grid";
import AgeRestrictionModal from "@/components/age-restriction-modal";
import { Youtube } from "lucide-react";

export default function Home() {
  const [showAgeModal, setShowAgeModal] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-emerald-50 relative overflow-hidden">
      {/* Animated Background Pattern */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-20 left-20 w-72 h-72 bg-primary rounded-full mix-blend-multiply filter blur-xl animate-pulse"></div>
        <div className="absolute top-40 right-20 w-72 h-72 bg-emerald-500 rounded-full mix-blend-multiply filter blur-xl animate-pulse animation-delay-2000"></div>
        <div className="absolute bottom-20 left-1/3 w-72 h-72 bg-purple-400 rounded-full mix-blend-multiply filter blur-xl animate-pulse animation-delay-4000"></div>
      </div>

      {/* Header */}
      <header className="relative z-10 pt-8 pb-4">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-2">
              <Youtube className="inline-block text-red-500 mr-3 w-8 h-8 md:w-10 md:h-10" />
              yt-indir.com
            </h1>
            <p className="text-muted-foreground text-lg">Fast, secure YouTube video downloads</p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 flex-1 flex items-center justify-center px-4 py-8">
        <div className="w-full max-w-2xl">
          <DownloadCard onAgeRestricted={() => setShowAgeModal(true)} />
          <LegalCompliance />
          <FeaturesGrid />
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 py-8 mt-16">
        <div className="container mx-auto px-4 text-center">
          <p className="text-muted-foreground text-sm">
            © 2024 yt-indir.com • 
            <span className="text-emerald-500 font-medium"> 50+ users served this month</span> • 
            Built with ❤️ using React & Cloudflare Workers
          </p>
        </div>
      </footer>

      {/* Age Restriction Modal */}
      <AgeRestrictionModal 
        isOpen={showAgeModal} 
        onClose={() => setShowAgeModal(false)} 
      />
    </div>
  );
}
