import { useState, useCallback } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface VideoInfo {
  title: string;
  duration: string;
  channel: string;
  thumbnail: string;
  formats: string[];
}

interface UseDownloaderProps {
  onAgeRestricted: () => void;
}

export function useDownloader({ onAgeRestricted }: UseDownloaderProps) {
  const [videoInfo, setVideoInfo] = useState<VideoInfo | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [progressStatus, setProgressStatus] = useState("");
  const [downloadReady, setDownloadReady] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  // Video info mutation
  const videoInfoMutation = useMutation({
    mutationFn: async (url: string) => {
      const response = await apiRequest("POST", "/api/video-info", { url });
      return response.json();
    },
    onSuccess: (data) => {
      setVideoInfo(data);
      setError(null);
    },
    onError: (error: any) => {
      const message = error.message || "Failed to fetch video information";
      if (message.includes("age-restricted")) {
        onAgeRestricted();
      } else {
        setError(message);
        toast({
          title: "Error",
          description: message,
          variant: "destructive",
        });
      }
    },
  });

  // Download preparation mutation
  const downloadMutation = useMutation({
    mutationFn: async ({ url, quality }: { url: string; quality: string }) => {
      const response = await apiRequest("POST", "/api/prepare-download", { url, quality });
      return response.json();
    },
    onSuccess: () => {
      setDownloadReady(true);
      setIsProcessing(false);
      toast({
        title: "Download Ready!",
        description: "Your video is ready for download.",
      });
    },
    onError: (error: any) => {
      setIsProcessing(false);
      const message = error.message || "Download preparation failed";
      setError(message);
      toast({
        title: "Download Error",
        description: message,
        variant: "destructive",
      });
    },
  });

  const simulateProgress = useCallback(() => {
    const statuses = [
      "Validating URL...",
      "Fetching video metadata...",
      "Extracting video stream...",
      "Processing quality selection...",
      "Preparing download...",
      "Almost ready..."
    ];

    let currentProgress = 0;
    const interval = setInterval(() => {
      currentProgress += Math.random() * 15 + 5;
      if (currentProgress > 95) currentProgress = 95;

      setProgress(currentProgress);
      const statusIndex = Math.min(Math.floor(currentProgress / 20), statuses.length - 1);
      setProgressStatus(statuses[statusIndex]);

      if (currentProgress >= 95) {
        clearInterval(interval);
        setProgress(100);
        setProgressStatus("Finalizing...");
      }
    }, 300);

    return interval;
  }, []);

  const startDownload = useCallback(async (url: string, quality: string) => {
    setError(null);
    setIsProcessing(true);
    setProgress(0);
    setDownloadReady(false);

    try {
      // First get video info
      await videoInfoMutation.mutateAsync(url);
      
      // Start progress simulation
      const progressInterval = simulateProgress();
      
      // Prepare download
      await downloadMutation.mutateAsync({ url, quality });
      
      clearInterval(progressInterval);
      setProgress(100);
    } catch (error) {
      setIsProcessing(false);
      // Error handling is done in mutation callbacks
    }
  }, [videoInfoMutation, downloadMutation, simulateProgress]);

  const downloadFile = useCallback(async (url: string, quality: string) => {
    try {
      const response = await fetch("/api/download", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url, quality }),
      });

      if (!response.ok) {
        throw new Error("Download failed");
      }

      // Create download link
      const blob = await response.blob();
      const downloadUrl = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = downloadUrl;
      link.download = `${videoInfo?.title || "video"}.mp4`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(downloadUrl);

      toast({
        title: "Download Started",
        description: "Your video download has started.",
      });
    } catch (error) {
      toast({
        title: "Download Failed",
        description: "Failed to download the video. Please try again.",
        variant: "destructive",
      });
    }
  }, [videoInfo, toast]);

  const reset = useCallback(() => {
    setVideoInfo(null);
    setIsProcessing(false);
    setProgress(0);
    setProgressStatus("");
    setDownloadReady(false);
    setError(null);
  }, []);

  return {
    videoInfo,
    isProcessing,
    progress,
    progressStatus,
    downloadReady,
    error,
    startDownload,
    downloadFile,
    reset,
  };
}
