/**
 * YouTube URL validation using regex pattern matching
 * Supports various YouTube URL formats including:
 * - youtube.com/watch?v=...
 * - youtu.be/...
 * - youtube.com/embed/...
 * - youtube.com/v/...
 */
export const YOUTUBE_URL_REGEX = /(youtu\.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;

export function validateYouTubeURL(url: string): boolean {
  if (!url || typeof url !== 'string') {
    return false;
  }
  
  return YOUTUBE_URL_REGEX.test(url.trim());
}

export function extractVideoId(url: string): string | null {
  const match = url.match(YOUTUBE_URL_REGEX);
  return match && match[2] ? match[2] : null;
}

export function isValidVideoId(videoId: string): boolean {
  // YouTube video IDs are typically 11 characters long
  return /^[a-zA-Z0-9_-]{11}$/.test(videoId);
}

/**
 * Quality options with fallback logic
 */
export const QUALITY_OPTIONS = [
  { value: "360p", label: "360p - Good (Mobile)", priority: 1 },
  { value: "480p", label: "480p - Good", priority: 2 },
  { value: "720p", label: "720p - HD (Recommended)", priority: 3 },
  { value: "1080p", label: "1080p - Full HD", priority: 4 },
  { value: "1440p", label: "1440p - QHD", priority: 5 },
  { value: "2160p", label: "2160p - 4K UHD", priority: 6 }
];

export function getQualityFallback(requestedQuality: string, availableQualities: string[]): string {
  // Try to find exact match first
  if (availableQualities.includes(requestedQuality)) {
    return requestedQuality;
  }
  
  // Find the closest lower quality
  const requested = QUALITY_OPTIONS.find(q => q.value === requestedQuality);
  if (!requested) return availableQualities[0] || "720p";
  
  const available = QUALITY_OPTIONS.filter(q => availableQualities.includes(q.value));
  const fallback = available
    .filter(q => q.priority <= requested.priority)
    .sort((a, b) => b.priority - a.priority)[0];
    
  return fallback ? fallback.value : available[0]?.value || "720p";
}
