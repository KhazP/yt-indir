import { Shield, Info } from "lucide-react";

export default function LegalCompliance() {
  return (
    <div className="bg-glass backdrop-blur-lg rounded-2xl shadow-lg border-glass p-6 mb-8">
      <div className="flex items-start space-x-4">
        <Shield className="text-primary text-2xl flex-shrink-0 mt-1 w-6 h-6" />
        <div>
          <h3 className="font-semibold text-foreground text-lg mb-2">Legal Compliance Notice</h3>
          <p className="text-muted-foreground text-sm leading-relaxed mb-3">
            By using this service, you agree to comply with YouTube's Terms of Service. Only download videos you have permission to download or that are in the public domain.
          </p>
          <p className="text-muted-foreground text-xs flex items-center">
            <Info className="w-3 h-3 mr-1" />
            No personal data is stored. All processing is done transiently and securely.
          </p>
        </div>
      </div>
    </div>
  );
}
