import { Zap, Lock, Smartphone } from "lucide-react";

export default function FeaturesGrid() {
  const features = [
    {
      icon: Zap,
      title: "Lightning Fast",
      description: "Process videos in under 2.5 seconds with our optimized pipeline",
      bgColor: "bg-blue-100",
      iconColor: "text-primary"
    },
    {
      icon: Lock,
      title: "Secure & Private",
      description: "Zero data persistence. Your URLs are processed and forgotten",
      bgColor: "bg-emerald-100",
      iconColor: "text-emerald-500"
    },
    {
      icon: Smartphone,
      title: "Mobile Optimized",
      description: "Perfect experience across all devices with responsive design",
      bgColor: "bg-purple-100",
      iconColor: "text-purple-500"
    }
  ];

  return (
    <div className="grid md:grid-cols-3 gap-6">
      {features.map((feature, index) => (
        <div key={index} className="bg-glass backdrop-blur-lg rounded-2xl shadow-lg border-glass p-6 text-center">
          <div className={`w-16 h-16 ${feature.bgColor} rounded-full flex items-center justify-center mx-auto mb-4`}>
            <feature.icon className={`${feature.iconColor} w-8 h-8`} />
          </div>
          <h4 className="font-semibold text-foreground mb-2">{feature.title}</h4>
          <p className="text-muted-foreground text-sm">{feature.description}</p>
        </div>
      ))}
    </div>
  );
}
