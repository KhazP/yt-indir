import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { AlertTriangle } from "lucide-react";

interface AgeRestrictionModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AgeRestrictionModal({ isOpen, onClose }: AgeRestrictionModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md w-full p-8 rounded-3xl">
        <div className="text-center">
          <div className="w-20 h-20 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <AlertTriangle className="text-amber-500 w-12 h-12" />
          </div>
          <DialogHeader className="space-y-4">
            <DialogTitle className="text-2xl font-bold text-foreground">
              Age-Restricted Content
            </DialogTitle>
            <DialogDescription className="text-muted-foreground leading-relaxed">
              This video is age-restricted by YouTube. Due to policy compliance, we cannot process age-restricted content.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 mt-6">
            <Button 
              onClick={onClose}
              className="w-full bg-primary hover:bg-primary/90 text-white font-semibold py-3 px-6 rounded-2xl"
            >
              I Understand
            </Button>
            <Button 
              onClick={onClose}
              variant="ghost"
              className="w-full text-muted-foreground hover:text-foreground font-medium py-2"
            >
              Try Different Video
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
