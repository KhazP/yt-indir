import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Settings } from "lucide-react";

interface QualitySelectorProps {
  value: string;
  onChange: (value: string) => void;
  disabled?: boolean;
  availableQualities?: string[];
}

const defaultQualities = [
  { value: "360p", label: "360p - Good (Mobile)" },
  { value: "720p", label: "720p - HD (Recommended)" },
  { value: "1080p", label: "1080p - Full HD" }
];

export default function QualitySelector({ 
  value, 
  onChange, 
  disabled, 
  availableQualities = [] 
}: QualitySelectorProps) {
  // Use available qualities from video info if provided, otherwise use defaults
  const qualities = availableQualities.length > 0 
    ? availableQualities.map(q => ({ value: q, label: `${q} - ${getQualityDescription(q)}` }))
    : defaultQualities;

  return (
    <div className="mb-8">
      <Label className="block text-foreground font-semibold text-lg mb-4">
        <Settings className="inline-block w-5 h-5 mr-2 text-primary" />
        Video Quality
      </Label>
      <Select value={value} onValueChange={onChange} disabled={disabled}>
        <SelectTrigger className="w-full px-6 py-4 text-lg border-2 border-gray-200 rounded-2xl focus:border-primary focus:ring-4 focus:ring-blue-100 transition-all duration-300 bg-white/80 backdrop-blur-sm">
          <SelectValue placeholder="Select quality..." />
        </SelectTrigger>
        <SelectContent>
          {qualities.map((quality) => (
            <SelectItem key={quality.value} value={quality.value}>
              {quality.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}

function getQualityDescription(quality: string): string {
  const descriptions: Record<string, string> = {
    "360p": "Good (Mobile)",
    "480p": "Good",
    "720p": "HD (Recommended)",
    "1080p": "Full HD",
    "1440p": "QHD",
    "2160p": "4K UHD"
  };
  return descriptions[quality] || "Quality";
}
