import { Progress } from "@/components/ui/progress";

interface ProgressSectionProps {
  progress: number;
  status: string;
}

export default function ProgressSection({ progress, status }: ProgressSectionProps) {
  return (
    <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 border border-white/40">
      <div className="flex items-center justify-between mb-3">
        <span className="text-foreground font-medium">Processing video...</span>
        <span className="text-foreground font-medium">{Math.round(progress)}%</span>
      </div>
      <Progress 
        value={progress} 
        className="w-full h-3 mb-2"
      />
      <p className="text-muted-foreground text-sm">
        {status}
      </p>
    </div>
  );
}
