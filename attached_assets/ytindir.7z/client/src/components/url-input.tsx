import { useState, useRef } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Link, Clipboard, AlertTriangle } from "lucide-react";
import { validateYouTubeURL } from "@/lib/youtube-utils";
import { useToast } from "@/hooks/use-toast";

interface UrlInputProps {
  value: string;
  onChange: (value: string) => void;
  error?: string | null;
  disabled?: boolean;
}

export default function UrlInput({ value, onChange, error, disabled }: UrlInputProps) {
  const [validationError, setValidationError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleInputChange = (newValue: string) => {
    onChange(newValue);
    
    if (newValue && !validateYouTubeURL(newValue)) {
      setValidationError("Please enter a valid YouTube URL");
    } else {
      setValidationError(null);
    }
  };

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        handleInputChange(text);
        inputRef.current?.focus();
        toast({
          title: "URL Pasted",
          description: "YouTube URL has been pasted from clipboard",
        });
      }
    } catch (err) {
      toast({
        title: "Paste Failed",
        description: "Unable to access clipboard. Please paste manually.",
        variant: "destructive",
      });
    }
  };

  const displayError = error || validationError;

  return (
    <div className="mb-8">
      <Label htmlFor="youtube-url" className="block text-foreground font-semibold text-lg mb-4">
        <Link className="inline-block w-5 h-5 mr-2 text-primary" />
        Paste YouTube URL
      </Label>
      <div className="relative">
        <Input
          ref={inputRef}
          type="url"
          id="youtube-url"
          placeholder="https://www.youtube.com/watch?v=..."
          value={value}
          onChange={(e) => handleInputChange(e.target.value)}
          disabled={disabled}
          className={`w-full px-6 py-4 text-lg border-2 rounded-2xl focus:ring-4 transition-all duration-300 bg-white/80 backdrop-blur-sm ${
            displayError 
              ? 'border-destructive focus:border-destructive focus:ring-red-100' 
              : 'border-gray-200 focus:border-primary focus:ring-blue-100'
          }`}
        />
        <Button
          type="button"
          onClick={handlePaste}
          disabled={disabled}
          className="absolute right-3 top-1/2 transform -translate-y-1/2 px-4 py-2 bg-primary text-white rounded-xl hover:bg-primary/90 transition-colors duration-200 text-sm font-medium h-auto"
        >
          <Clipboard className="w-4 h-4 mr-1" />
          Paste
        </Button>
      </div>
      
      {displayError && (
        <div className="mt-2">
          <p className="text-destructive text-sm flex items-center">
            <AlertTriangle className="w-4 h-4 mr-2" />
            {displayError}
          </p>
        </div>
      )}
    </div>
  );
}
