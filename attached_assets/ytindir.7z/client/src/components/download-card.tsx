import { useState } from "react";
import UrlInput from "./url-input";
import QualitySelector from "./quality-selector";
import ProgressSection from "./progress-section";
import { useDownloader } from "@/hooks/use-downloader";
import { Button } from "@/components/ui/button";
import { Download, CloudDownload } from "lucide-react";

interface DownloadCardProps {
  onAgeRestricted: () => void;
}

export default function DownloadCard({ onAgeRestricted }: DownloadCardProps) {
  const [url, setUrl] = useState("");
  const [quality, setQuality] = useState("720p");
  
  const {
    videoInfo,
    isProcessing,
    progress,
    progressStatus,
    downloadReady,
    error,
    startDownload,
    downloadFile,
    reset
  } = useDownloader({ onAgeRestricted });

  const handleDownload = () => {
    if (!url.trim()) return;
    startDownload(url, quality);
  };

  const handleReset = () => {
    setUrl("");
    setQuality("720p");
    reset();
  };

  return (
    <div className="bg-glass backdrop-blur-lg rounded-3xl shadow-2xl border-glass p-8 md:p-12 mb-8">
      <UrlInput 
        value={url}
        onChange={setUrl}
        error={error}
        disabled={isProcessing}
      />
      
      <QualitySelector 
        value={quality}
        onChange={setQuality}
        disabled={isProcessing || !url}
        availableQualities={videoInfo?.formats || []}
      />

      <div className="space-y-6">
        {/* Video Preview */}
        {videoInfo && (
          <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 border border-white/40">
            <div className="flex items-start space-x-4">
              <img 
                src={videoInfo.thumbnail} 
                alt="Video thumbnail" 
                className="w-32 h-24 object-cover rounded-xl shadow-md flex-shrink-0"
              />
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-foreground text-lg mb-2 truncate">
                  {videoInfo.title}
                </h3>
                <p className="text-muted-foreground text-sm mb-2">
                  Duration: {videoInfo.duration}
                </p>
                <p className="text-muted-foreground text-xs">
                  {videoInfo.channel}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Progress Section */}
        {isProcessing && (
          <ProgressSection 
            progress={progress}
            status={progressStatus}
          />
        )}

        {/* Download Button */}
        {!downloadReady ? (
          <Button 
            onClick={handleDownload}
            disabled={!url.trim() || isProcessing || !!error}
            className="w-full bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white font-bold py-4 px-8 rounded-2xl text-lg h-auto transition-all duration-300 transform hover:scale-105 focus:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
          >
            <Download className="mr-3 w-5 h-5" />
            Download Video
          </Button>
        ) : (
          <div className="space-y-3">
            <Button 
              onClick={() => downloadFile(url, quality)}
              className="w-full bg-gradient-to-r from-primary to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-bold py-4 px-8 rounded-2xl text-lg h-auto transition-all duration-300 transform hover:scale-105 focus:scale-105"
            >
              <CloudDownload className="mr-3 w-5 h-5" />
              Download Ready - Click to Save
            </Button>
            <Button 
              onClick={handleReset}
              variant="outline"
              className="w-full py-2 rounded-xl"
            >
              Download Another Video
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
